// JS -To make websites more interactive,more responsive and functionally
//JS is programing language 
//frontend - High level => (v8-engene) low level
//Backend - Js -> nodejs
// in.java -> javac in.java => in.class(byte) => java in mc
console.log("Hello World!")
//Variable -
//types ->integer,decimal,boolean,strings,arrays
//syntax : Var Var_name=value;let-new,var-old,const
let y=10;
const a=2;
console.log(a)
let boolean=true;
let name="ABC";
console.log(name)
console.log(typeof(a))
//arr
var arr =[1,2,3,4];
var arr1=[1,2,3,"Hello"];
console.log(arr[0]);
console.log(arr1);
//undefined
let b = undefined;
//object
let student1={studentname:"XYZ",
    Reg_no:12345,
    Hobbies:["h1","h2","h3"]
}
console.log(student1.studentname);
console.log(student1.Reg_no);
console.log(student1.Hobbies);
//function  
function add(x,y){
    return x+y
}
add(7,8)

//calling function wchich function without name 
console.log(function(x,y){return x+y}(4,3));
//calling arrow function
var fun1 = ((x,y)=>{return x+y});
console.log(fun1(6,5));
//call back function

//add sub
