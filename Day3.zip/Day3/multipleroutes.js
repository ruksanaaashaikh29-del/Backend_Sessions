const express= require('express');
const app = express();

app.get('/', (req, res) => {
res.send('Home Page');
});

app.get('/about', (req, res) => {
res.send('About Page');
});

app.get('/contact', (req, res) => {
res.send('contact Page');
});

app.get('/profile', (req, res) => {
res.send('Profile Page');
});

app.listen(3000, () => {
console.log('Server running on port 3000');
})