const express = require('express');
const app = express();
//json
//get API-post,put,delete
//Middle ware
app.use((req,res,next) => {
console.log("inside middleware")
res.send("hacker ur too smart")
next()
});
app.get('/index', (req, res) => {
//json data = {key:value}
    res.status(404).json({msg:"Page Not Found"})
})

app.listen(3000,() => {
console.log('Server running on port 3000');
})
